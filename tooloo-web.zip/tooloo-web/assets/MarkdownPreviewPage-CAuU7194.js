import{j as s,h as b,C as x,a as p,b as h,d as C,B as r,e as u,t}from"./index-UWVnAYg3.js";import{b as n}from"./react-vendor-23HEpp2O.js";import{T as M}from"./textarea-BTW96NFh.js";import{T,a as z,b as j}from"./tabs-t5-i7jA4.js";import{u as H,C as L,a as g}from"./useCopy-D2q65a2E.js";import{d as R}from"./markdown-vendor-C0Rlrcoy.js";import{P as D}from"./PageHeader-sTvRU5FU.js";import{D as P}from"./download-BgiXRjKI.js";import{T as S}from"./trash-2-DONUBkYH.js";import"./index-CC0CdCv1.js";const U=`# Markdown 预览

这是一个 **Markdown 预览** 工具，支持实时渲染。

## 功能特性

- 实时预览
- 代码高亮
- 表格支持
- 任务列表

## 代码示例

\`\`\`javascript
function hello() {
  console.log("Hello, World!");
}
\`\`\`

## 表格

| 名称 | 描述 |
|------|------|
| React | 前端框架 |
| TypeScript | 类型系统 |

## 任务列表

- [x] 已完成
- [ ] 未完成

> 引用文本

---

[链接](https://example.com)
`;function q(){const[a,o]=n.useState(U),[c,N]=n.useState("split"),{copied:w,copy:l}=H(),i=n.useMemo(()=>{try{return R(a,{breaks:!0,gfm:!0})}catch{return"<p>Markdown 解析错误</p>"}},[a]),v=async()=>{await l(a)&&t.success("已复制 Markdown 源码")},f=async()=>{await l(i)&&t.success("已复制 HTML")},y=()=>{o("")},k=()=>{const e=new Blob([a],{type:"text/markdown"}),m=URL.createObjectURL(e),d=document.createElement("a");d.href=m,d.download="document.md",d.click(),URL.revokeObjectURL(m),t.success("已下载 Markdown 文件")};return s.jsxs("div",{className:"space-y-6",children:[s.jsx(D,{icon:s.jsx(b,{className:"size-6"}),title:"Markdown 预览",description:"实时预览 Markdown 文档，支持 GFM 语法"}),s.jsxs(x,{children:[s.jsx(p,{children:s.jsxs("div",{className:"flex items-center justify-between flex-wrap gap-4",children:[s.jsxs("div",{children:[s.jsx(h,{className:"text-lg",children:"编辑器"}),s.jsx(C,{children:"输入 Markdown 内容"})]}),s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(T,{value:c,onValueChange:e=>N(e),children:s.jsxs(z,{children:[s.jsx(j,{value:"split",children:"分栏"}),s.jsx(j,{value:"preview",children:"预览"})]})}),s.jsxs(r,{variant:"outline",size:"sm",onClick:v,children:[w?s.jsx(L,{className:"size-4"}):s.jsx(g,{className:"size-4"}),"复制 MD"]}),s.jsxs(r,{variant:"outline",size:"sm",onClick:f,children:[s.jsx(g,{className:"size-4"}),"复制 HTML"]}),s.jsxs(r,{variant:"outline",size:"sm",onClick:k,children:[s.jsx(P,{className:"size-4"}),"下载"]}),s.jsx(r,{variant:"ghost",size:"sm",onClick:y,children:s.jsx(S,{className:"size-4"})})]})]})}),s.jsx(u,{children:s.jsxs("div",{className:`grid gap-4 ${c==="split"?"grid-cols-1 md:grid-cols-2":"grid-cols-1"}`,children:[c==="split"&&s.jsx(M,{value:a,onChange:e=>o(e.target.value),placeholder:"输入 Markdown...",className:"min-h-[500px] font-mono text-sm resize-none"}),s.jsx("div",{className:`prose prose-sm dark:prose-invert max-w-none p-4 border rounded-lg overflow-auto ${c==="split"?"min-h-[500px] max-h-[500px]":"min-h-[600px]"}`,dangerouslySetInnerHTML:{__html:i}})]})})]}),s.jsxs(x,{children:[s.jsx(p,{children:s.jsx(h,{className:"text-lg",children:"快捷语法参考"})}),s.jsx(u,{children:s.jsxs("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4 text-sm",children:[s.jsxs("div",{className:"space-y-1",children:[s.jsx("p",{className:"font-medium",children:"标题"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"# H1"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"## H2"})]}),s.jsxs("div",{className:"space-y-1",children:[s.jsx("p",{className:"font-medium",children:"强调"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"**粗体**"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"*斜体*"})]}),s.jsxs("div",{className:"space-y-1",children:[s.jsx("p",{className:"font-medium",children:"列表"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"- 无序"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"1. 有序"})]}),s.jsxs("div",{className:"space-y-1",children:[s.jsx("p",{className:"font-medium",children:"其他"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"[链接](url)"}),s.jsx("code",{className:"text-xs bg-muted px-1 py-0.5 rounded",children:"`代码`"})]})]})})]})]})}export{q as MarkdownPreviewPage};
